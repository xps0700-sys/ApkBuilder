package com.example.whatsapprecovery

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var countView: TextView
    private val db by lazy { AppDatabase.get(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        countView = findViewById(R.id.countView)

        findViewById<android.view.View>(R.id.enableButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<android.view.View>(R.id.clearButton).setOnClickListener {
            Thread {
                db.deleteAll()
                runOnUiThread { updateCount() }
            }.start()
        }
    }

    override fun onResume() {
        super.onResume()
        updateCount()
    }

    private fun updateCount() {
        Thread {
            val count = db.count()
            runOnUiThread { countView.text = count.toString() }
        }.start()
    }
}
