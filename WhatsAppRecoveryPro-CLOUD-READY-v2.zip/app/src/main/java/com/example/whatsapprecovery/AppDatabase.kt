package com.example.whatsapprecovery

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabase private constructor(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DB_NAME,
    null,
    DB_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE captured_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                package_name TEXT NOT NULL,
                conversation TEXT NOT NULL,
                content TEXT NOT NULL,
                kind TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )""".trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Reserved for future schema upgrades.
    }

    fun insert(item: CapturedItem) {
        val values = ContentValues().apply {
            put("package_name", item.packageName)
            put("conversation", item.conversation)
            put("content", item.content)
            put("kind", item.kind)
            put("timestamp", item.timestamp)
        }
        writableDatabase.insert("captured_items", null, values)
    }

    fun count(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM captured_items", null).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getInt(0) else 0
        }
    }

    fun deleteAll() {
        writableDatabase.delete("captured_items", null, null)
    }

    companion object {
        private const val DB_NAME = "whatsapp_recovery.db"
        private const val DB_VERSION = 1

        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: AppDatabase(context).also { INSTANCE = it }
            }
    }
}

data class CapturedItem(
    val id: Long = 0,
    val packageName: String,
    val conversation: String,
    val content: String,
    val kind: String,
    val timestamp: Long
)
